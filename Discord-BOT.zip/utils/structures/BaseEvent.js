module.exports = class BaseEvent {
  constructor (name) {
    this.name = name;
  }
}